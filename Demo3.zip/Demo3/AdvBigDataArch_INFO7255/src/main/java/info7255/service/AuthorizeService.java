package info7255.service;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.TimeZone;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.apache.ApacheHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;

@Service
public class AuthorizeService {

	// parse client id
	// TODO: insert your own google secret id here
	private static final JacksonFactory jacksonFactory = new JacksonFactory();
	GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(new ApacheHttpTransport(), jacksonFactory)
			.setAudience(Collections.singletonList("your secret id")).build();

	private static final Charset UTF_8 = StandardCharsets.UTF_8;
	private static final String OUTPUT_FORMAT = "%-20s:%s";
	private static final String key = "ssdkF$HUy2A#D%kd";
	private static final String algorithm = "AES";

	// verify google token
//	public boolean authorize(String idTokenString) {
//
//		try {
//			GoogleIdToken idToken = verifier.verify(idTokenString);
//			if (idToken != null) return true;
//			return false;
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//			return false;}
//	}
	private static byte[] digest(byte[] input) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("MD5");
		byte[] result = md.digest(input);
		return result;
	}

	private static String bytesToHex(byte[] bytes) {
		StringBuilder sb = new StringBuilder();
		for (byte b : bytes) {
			sb.append(String.format("%02x", b));
		}
		return sb.toString();
	}

	public static String hashString(String data) throws NoSuchAlgorithmException {
		byte[] md5InBytes = AuthorizeService.digest(data.getBytes(UTF_8));
		String bytesToHex = AuthorizeService.bytesToHex(md5InBytes);

		return bytesToHex;
	}

	public static JSONObject getJsonObjectFromString(String jsonString) {
		return new JSONObject(jsonString);
	}

	public String createAuthToken() {
		String encoded = null;
		JSONObject jsonToken = new JSONObject();
		jsonToken.put("Issuer", "Sachin");

		TimeZone tz = TimeZone.getTimeZone("UTC");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ssssZ");
		df.setTimeZone(tz);

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		calendar.add(Calendar.MINUTE, 60);
		Date date = calendar.getTime();

		jsonToken.put("expiry", df.format(date));
		String token = jsonToken.toString();
		System.out.println(token);
		SecretKey spec = loadKey();

		try {
			Cipher c = Cipher.getInstance(algorithm);
			c.init(Cipher.ENCRYPT_MODE, spec);
			byte[] encrBytes = c.doFinal(token.getBytes());
			encoded = Base64.getEncoder().encodeToString(encrBytes);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return encoded;
	}

	private static SecretKey loadKey() {
		return new SecretKeySpec(key.getBytes(), algorithm);
	}

	public boolean authorize(String token) {
//		if (headers.getFirst("Authorization") == null)
//			return false;

		//String token = headers.getFirst("Authorization").substring(7);
		byte[] decrToken = Base64.getDecoder().decode(token);
		SecretKey spec = loadKey();
		try {
			Cipher c = Cipher.getInstance(algorithm);
			c.init(Cipher.DECRYPT_MODE, spec);
			String tokenString = new String(c.doFinal(decrToken));
			JSONObject jsonToken = new JSONObject(tokenString);

			String ttldateAsString = jsonToken.get("expiry").toString();
			Date currentDate = Calendar.getInstance().getTime();

			TimeZone tz = TimeZone.getTimeZone("UTC");
			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ssssZ");
			formatter.setTimeZone(tz);

			Date ttlDate = formatter.parse(ttldateAsString);
			currentDate = formatter.parse(formatter.format(currentDate));

			if (currentDate.after(ttlDate)) {
				return false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
